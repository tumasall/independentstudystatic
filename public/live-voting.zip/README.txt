A Pen created at CodePen.io. You can find this one at http://codepen.io/tumasall/pen/VaqMNZ.

 

Forked from [Ariana Lynn](http://codepen.io/arianalynn/)'s Pen [Live Voting](http://codepen.io/arianalynn/pen/ZWBBNv/).