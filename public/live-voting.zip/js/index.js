function g() {
  var colors = ["#0066FF", "#000080", "#000080", "mediumorchid"];
  $.getJSON("https://spreadsheets.google.com/feeds/list/10OPoiA7s3Bjuc3OekRJsEhfDF28I2Sx6GyIG4l90M5A/od6/public/values?alt=json", function(data) {
    for (var i = 0; i < 4; i++) {
      document.getElementsByClassName('bar')[i].style.height = (data.feed.entry[i].gsx$number.$t / data.feed.entry[4].gsx$number.$t * 500) + 'px';
      document.getElementsByClassName('bar')[i].innerHTML = data.feed.entry[i].gsx$option.$t + '<br/><small>' + Math.floor(100 * data.feed.entry[i].gsx$number.$t / data.feed.entry[4].gsx$number.$t) + '%</small>';
      document.getElementsByClassName('bar')[i].style.background = colors[i];
      document.getElementsByClassName('pie')[i].style.background = 'linear-gradient(0deg, transparent 50%, transparent 50%),linear-gradient(' + Math.floor(360 * data.feed.entry[i].gsx$number.$t / data.feed.entry[4].gsx$number.$t) + 'deg, transparent 50%, ' + colors[i] + ' 50%)';
      if (i != 0) {
        document.getElementsByClassName('pie')[i].style.webkitTransform = 'rotate(' + Math.floor(360 * data.feed.entry[i - 1].gsx$number.$t / data.feed.entry[4].gsx$number.$t) + 'deg) ' + document.getElementsByClassName('pie')[i - 1].style.webkitTransform;
      }
    }
  });
}
g();